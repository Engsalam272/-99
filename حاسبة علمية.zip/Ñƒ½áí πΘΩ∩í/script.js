function calculate() {
    const operation = document.getElementById('operation').value;
    const num1 = parseFloat(document.getElementById('num1').value);
    let result;

    switch (operation) {
        // العمليات التي تتطلب رقمين
        case 'add':
        case 'subtract':
        case 'multiply':
        case 'divide':
        case 'power':
        case 'modulus':
            const num2 = parseFloat(document.getElementById('num2').value);
            result = performMathOperation(operation, num1, num2);
            break;

        // العمليات التي تتطلب رقم واحد
        case 'sqrt':
            result = Math.sqrt(num1);
            break;
        case 'sin':
            result = Math.sin(num1 * (Math.PI / 180)); // تحويل من درجات إلى راديان
            break;
        case 'cos':
            result = Math.cos(num1 * (Math.PI / 180)); // تحويل من درجات إلى راديان
            break;
        case 'tan':
            result = Math.tan(num1 * (Math.PI / 180)); // تحويل من درجات إلى راديان
            break;
        case 'log':
            result = Math.log10(num1);
            break;
        case 'ln':
            result = Math.log(num1);
            break;
        case 'factorial':
            result = factorial(num1);
            break;
        case 'abs':
            result = Math.abs(num1);
            break;
        case 'exp':
            result = Math.exp(num1);
            break;
        case 'pi':
            result = Math.PI;
            break;
        case 'degToRad':
            result = num1 * (Math.PI / 180);
            break;
        case 'radToDeg':
            result = num1 * (180 / Math.PI);
            break;

        // تحويلات الطول
        case 'meterToCm':
            result = num1 * 100;
            break;
        case 'cmToMeter':
            result = num1 / 100;
            break;
        case 'kmToMeter':
            result = num1 * 1000;
            break;
        case 'meterToKm':
            result = num1 / 1000;
            break;
        case 'inchToCm':
            result = num1 * 2.54;
            break;
        case 'cmToInch':
            result = num1 / 2.54;
            break;
        case 'footToMeter':
            result = num1 * 0.3048;
            break;
        case 'meterToFoot':
            result = num1 / 0.3048;
            break;

        // تحويلات الوزن
        case 'kgToGram':
            result = num1 * 1000;
            break;
        case 'gramToKg':
            result = num1 / 1000;
            break;
        case 'kgToPound':
            result = num1 * 2.20462;
            break;
        case 'poundToKg':
            result = num1 / 2.20462;
            break;
        case 'ounceToGram':
            result = num1 * 28.3495;
            break;
        case 'gramToOunce':
            result = num1 / 28.3495;
            break;

        // تحويلات الحجم
        case 'literToMilliliter':
            result = num1 * 1000;
            break;
        case 'milliliterToLiter':
            result = num1 / 1000;
            break;
        case 'gallonToLiter':
            result = num1 * 3.78541;
            break;
        case 'literToGallon':
            result = num1 / 3.78541;
            break;

        // تحويلات الوقت
        case 'secondToMinute':
            result = num1 / 60;
            break;
        case 'minuteToSecond':
            result = num1 * 60;
            break;
        case 'hourToMinute':
            result = num1 * 60;
            break;
        case 'minuteToHour':
            result = num1 / 60;
            break;
        default:
            result = 'عملية غير صالحة';
    }

    document.getElementById('result').innerText = 'النتيجة: ' + result;
    document.getElementById('display').value = result;
}

function performMathOperation(operation, num1, num2) {
    switch (operation) {
        case 'add':
            return num1 + num2;
        case 'subtract':
            return num1 - num2;
        case 'multiply':
            return num1 * num2;
        case 'divide':
            return num1 / num2;
        case 'power':
            return Math.pow(num1, num2);
        case 'modulus':
            return num1 % num2;
        default:
            return 'عملية غير صالحة';
    }
}

function factorial(n) {
    if (n === 0 || n === 1) return 1;
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

function clearScreen() {
    document.getElementById('num1').value = '';
    document.getElementById('num2').value = '';
    document.getElementById('display').value = '0';
    document.getElementById('result').innerText = 'النتيجة: ';
}

function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
}

function toggleSecondInput() {
    const operation = document.getElementById('operation').value;
    const num2Input = document.getElementById('num2');

    // العمليات التي تتطلب رقمين
    const twoInputOperations = ['add', 'subtract', 'multiply', 'divide', 'power', 'modulus'];

    if (twoInputOperations.includes(operation)) {
        num2Input.style.display = 'block';
    } else {
        num2Input.style.display = 'none';
    }
}